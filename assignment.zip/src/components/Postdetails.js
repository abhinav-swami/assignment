import React, { Component } from 'react';

class Postdetails extends Component {
    render() {
        return (
            <div>
                <h1>post details and comments page</h1>
              
            </div>
        );
    }
}

export default Postdetails;
